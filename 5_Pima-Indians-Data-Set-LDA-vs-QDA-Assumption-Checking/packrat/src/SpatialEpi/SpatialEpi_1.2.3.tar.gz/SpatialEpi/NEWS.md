# SpatialEpi 1.2.3

* Removed SpatialEpi-package.Rd file as per 



# SpatialEpi 1.2.2

* CRAN v 1.2.2 uploaded to GitHub