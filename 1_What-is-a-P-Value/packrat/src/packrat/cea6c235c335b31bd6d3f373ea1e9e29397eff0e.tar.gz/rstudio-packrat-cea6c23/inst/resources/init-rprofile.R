#### -- Packrat Autoloader (version 0.4.9-12) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
