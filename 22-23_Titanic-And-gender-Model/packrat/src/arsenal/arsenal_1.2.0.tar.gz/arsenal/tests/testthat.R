library(testthat)
library(arsenal)

test_check("arsenal")
