



Table: A Title for tableby

|                            |  Male (N=916)   | Female (N=583)  | Total (N=1499)  | p value|
|:---------------------------|:---------------:|:---------------:|:---------------:|-------:|
|**Age in Years**            |                 |                 |                 |   0.048|
|&nbsp;&nbsp;&nbsp;Mean (SD) | 60.455 (11.369) | 59.247 (11.722) | 59.985 (11.519) |        |
|&nbsp;&nbsp;&nbsp;Range     | 19.000 - 88.000 | 22.000 - 88.000 | 19.000 - 88.000 |        |





Table: A Title for modelsum

|               |estimate |std.error |p.value |adj.r.squared |
|:--------------|:--------|:---------|:-------|:-------------|
|(Intercept)    |60.455   |0.380     |< 0.001 |0.002         |
|**sex Female** |-1.208   |0.610     |0.048   |              |





Table: A Title for freqlist

|sex    | Freq| cumFreq| freqPercent| cumPercent|
|:------|----:|-------:|-----------:|----------:|
|Male   |  916|     916|       61.11|      61.11|
|Female |  583|    1499|       38.89|     100.00|



